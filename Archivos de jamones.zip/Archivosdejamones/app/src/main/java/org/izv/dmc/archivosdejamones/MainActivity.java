package org.izv.dmc.archivosdejamones;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import org.izv.dmc.archivosdejamones.data.Vino;
import org.izv.dmc.archivosdejamones.data.util.Csv;

public class MainActivity extends AppCompatActivity {
    public static final String TAG=MainActivity.class.getName()+"xyzyx";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    initialize();
    }

    private void initialize() {
        Vino vino=new Vino(5,"Betis","Man que pierda","Verde","Benito Villamarín",15.2,2013);
        String csv=Csv.getCsv(vino);
        Log.v(TAG,csv);
        Vino v2=Csv.getVino(csv);
        Log.v(TAG,v2.toString());
    }

}